All of my code is under the 'python' directory. 
'final work.pdf' has all of my handwritten work that corresponds to the questions asked in the 'final.pdf'.
'Final.docx' has all of the necessary plots. 
